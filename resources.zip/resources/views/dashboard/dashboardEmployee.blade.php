@extends('includeView.layout')
@section('content')

<div class="content-wrapper">
    <div class="row">
        <h1>Halo Pegawai RSI Nganjuk Selamat Datang</h1>
    </div>
</div>

@endsection