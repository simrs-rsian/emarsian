<footer class="footer">
    <div class="card">
    <div class="card-body">
        <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2024 <a href="https://www.rsiaisyiyahnganjuk.com/" class="text-muted" target="_blank">RSI Aisyiyah Nganjuk</a>. All rights reserved.</span>
        <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center text-muted">@addev.rsian (V. 1.2.7-beta) <i class="typcn typcn-heart-full-outline text-danger"></i></span>
        </div>
    </div>
    </div>
</footer>